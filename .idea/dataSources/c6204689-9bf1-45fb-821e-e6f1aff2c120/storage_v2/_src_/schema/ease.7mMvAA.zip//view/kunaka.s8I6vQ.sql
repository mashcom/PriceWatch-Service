create view kunaka as
select distinct `admission`.`enrolment`.`regnum` AS `regnum`, `admission`.`applicant_country`.`code` AS `code`
from (((`admission`.`applicant` join `admission`.`applicant_country`) join `admission`.`acceptance`)
         join `admission`.`enrolment`)
where ((`admission`.`applicant`.`id` = `admission`.`applicant_country`.`id`) and
       (`admission`.`applicant`.`id` = `admission`.`acceptance`.`applicantid`) and
       (`admission`.`acceptance`.`id` = `admission`.`enrolment`.`acceptanceid`));

