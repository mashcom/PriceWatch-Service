create definer = root@localhost trigger student_pin_insert
    after INSERT
    on student_pinnumber
    for each row
BEGIN
	
	DECLARE FoundCount INT;
	DECLARE regorec1 VARCHAR(50);
    SELECT COUNT(1) INTO FoundCount FROM information_schema.tables WHERE table_schema = 'esadza_svr' AND table_name = 'to_sync';
		IF FoundCount = 1 THEN
			SELECT regnum INTO regorec1 FROM student WHERE id = NEW.studentid;
			IF NOT ISNULL(regorec1) THEN
				INSERT IGNORE  INTO esadza_svr.to_sync(regorec,`value`,`action`) VALUES(regorec1,NEW.pinnumber,'pin');
			END IF;
		END IF;
		END;

