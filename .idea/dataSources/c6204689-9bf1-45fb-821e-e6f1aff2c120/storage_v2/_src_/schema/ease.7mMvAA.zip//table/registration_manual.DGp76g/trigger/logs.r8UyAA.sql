create definer = root@localhost trigger logs
    after INSERT
    on registration_manual
    for each row
    INSERT INTO  registration_log VALUES(NEW.id,'MANUAL',NOW());

