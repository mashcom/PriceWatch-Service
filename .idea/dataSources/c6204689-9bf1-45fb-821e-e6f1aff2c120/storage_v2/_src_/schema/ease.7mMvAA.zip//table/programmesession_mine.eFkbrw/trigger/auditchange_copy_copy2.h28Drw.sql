create definer = root@localhost trigger AuditChange_copy_copy2
    after UPDATE
    on programmesession_mine
    for each row
    INSERT INTO programmesessionaudit VALUES(NULL,OLD.id,OLD.intakeid,NEW.intakeid,NOW());

