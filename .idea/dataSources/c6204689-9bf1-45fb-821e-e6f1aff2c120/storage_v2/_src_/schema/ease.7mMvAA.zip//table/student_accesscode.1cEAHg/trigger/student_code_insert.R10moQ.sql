create definer = root@localhost trigger student_code_insert
    after INSERT
    on student_accesscode
    for each row
BEGIN
	
	DECLARE FoundCount INT;
	DECLARE regorec1 VARCHAR(50);
    SELECT COUNT(1) INTO FoundCount FROM information_schema.tables WHERE table_schema = 'esadza_svr' AND table_name = 'consumer_update';
		IF FoundCount = 1 THEN
			SELECT regnum INTO regorec1 FROM student WHERE id = NEW.studentid;
			IF NOT ISNULL(regorec1) THEN
				REPLACE INTO esadza_svr.consumer_update(regorec,is_student) VALUES(regorec1,1);
			END IF;
		END IF;
		END;

