create definer = root@localhost trigger BuxtTrack
    after INSERT
    on registeredmodule_mark
    for each row
    INSERT INTO works.auditmarks VALUES(NULL,NOW(),'INSERT',NEW.id,NEW.mark,NEW.gradingrule);

