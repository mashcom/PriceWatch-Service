create definer = root@localhost trigger BuxtTrack2
    after UPDATE
    on registeredmodule_mark
    for each row
    INSERT INTO works.auditmarks VALUES(NULL,NOW(),'UPDATE',NEW.id,NEW.mark,NEW.gradingrule);

