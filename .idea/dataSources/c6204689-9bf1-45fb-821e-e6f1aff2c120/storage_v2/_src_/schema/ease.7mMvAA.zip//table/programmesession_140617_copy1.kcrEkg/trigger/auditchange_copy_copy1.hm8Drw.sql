create definer = root@localhost trigger AuditChange_copy_copy1
    after UPDATE
    on programmesession_140617_copy1
    for each row
    INSERT INTO programmesessionaudit VALUES(NULL,OLD.id,OLD.intakeid,NEW.intakeid,NOW());

