create definer = root@`10.10.1.23` trigger AuditChange_copy_copy3
    after UPDATE
    on programmesession_copy6
    for each row
    INSERT INTO programmesessionaudit VALUES(NULL,OLD.id,OLD.intakeid,NEW.intakeid,NOW());

