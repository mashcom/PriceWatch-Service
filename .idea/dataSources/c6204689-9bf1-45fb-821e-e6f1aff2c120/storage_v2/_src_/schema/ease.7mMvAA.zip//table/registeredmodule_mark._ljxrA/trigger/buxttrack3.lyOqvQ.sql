create definer = root@localhost trigger BuxtTrack3
    after DELETE
    on registeredmodule_mark
    for each row
    INSERT INTO works.auditmarks VALUES(NULL,NOW(),'DELETE',OLD.id,OLD.mark,OLD.gradingrule);

