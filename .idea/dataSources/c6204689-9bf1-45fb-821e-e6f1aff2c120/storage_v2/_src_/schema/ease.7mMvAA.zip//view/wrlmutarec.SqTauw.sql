create view wrlmutarec as
select `ease`.`registration`.`id` AS `id`, `ease`.`registration`.`periodid` AS `periodid`
from (((((`ease`.`student` join `ease`.`programmesession`) join `ease`.`registration`) join `ease`.`registration_level`) join `ease`.`intake`)
         join `ease`.`programme`)
where ((`ease`.`programme`.`code` in ('HMIE', 'HCHE')) and (`ease`.`intake`.`attendancetypeid` in (1, 2)) and
       (`ease`.`programmesession`.`intakeid` = `ease`.`intake`.`id`) and
       (`ease`.`programme`.`id` = `ease`.`intake`.`programmeid`) and
       (`ease`.`student`.`id` = `ease`.`programmesession`.`studentid`) and
       (`ease`.`programmesession`.`id` = `ease`.`registration`.`programmesessionid`) and
       (`ease`.`registration`.`id` = `ease`.`registration_level`.`id`) and
       (`ease`.`registration_level`.`academicyear` = 3) and (`ease`.`registration_level`.`semester` = 2) and
       `ease`.`registration`.`id` in (select `ease`.`humandecision`.`registrationid` AS `registrationid`
                                      from `ease`.`humandecision`
                                      where (`ease`.`humandecision`.`decisiontype` in (2, 4))));

