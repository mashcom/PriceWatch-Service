create definer = root@localhost trigger Mbivholaz
    after INSERT
    on registration
    for each row
    INSERT INTO works.registration_audit VALUES(NULL,NEW.id,'NEW',NOW());

