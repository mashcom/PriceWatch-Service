create definer = root@localhost trigger AuditChange
    after UPDATE
    on programmesession_
    for each row
    INSERT INTO programmesessionaudit VALUES(NULL,OLD.id,OLD.intakeid,NEW.intakeid,NOW());

