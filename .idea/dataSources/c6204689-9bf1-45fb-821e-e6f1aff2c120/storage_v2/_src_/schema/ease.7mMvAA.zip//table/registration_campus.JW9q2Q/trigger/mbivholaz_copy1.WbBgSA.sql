create definer = root@localhost trigger Mbivholaz_copy1
    after INSERT
    on registration_campus
    for each row
    INSERT INTO works.registration_audit VALUES(NULL,NEW.id,'NEW',NOW());

