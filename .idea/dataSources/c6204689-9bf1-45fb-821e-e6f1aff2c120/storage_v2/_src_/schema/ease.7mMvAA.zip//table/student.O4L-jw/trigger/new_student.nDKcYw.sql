create definer = root@localhost trigger new_student
    after INSERT
    on student
    for each row
BEGIN
	
	DECLARE FoundCount INT;
	DECLARE regorec1 VARCHAR(50);
    SELECT COUNT(1) INTO FoundCount FROM information_schema.tables WHERE table_schema = 'esadza_svr' AND table_name = 'consumer_update';
		IF FoundCount = 1 THEN						
			REPLACE INTO esadza_svr.consumer_update(regorec,is_student) VALUES(NEW.regnum,1);			
		END IF;
		END;

