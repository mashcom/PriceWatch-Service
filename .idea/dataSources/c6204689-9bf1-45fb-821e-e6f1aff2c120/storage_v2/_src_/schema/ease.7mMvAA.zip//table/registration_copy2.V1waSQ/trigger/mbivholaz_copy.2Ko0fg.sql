create definer = root@localhost trigger Mbivholaz_copy
    after INSERT
    on registration_copy2
    for each row
    INSERT INTO works.registration_audit VALUES(NULL,NEW.id,'NEW',NOW());

