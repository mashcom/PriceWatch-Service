create definer = root@localhost trigger Mbivholaz_copy2
    after INSERT
    on registration_29112017
    for each row
    INSERT INTO works.registration_audit VALUES(NULL,NEW.id,'NEW',NOW());

