create definer = root@`10.10.1.23` trigger Mbivholaz_copy4
    after INSERT
    on registration_copy4
    for each row
    INSERT INTO works.registration_audit VALUES(NULL,NEW.id,'NEW',NOW());

