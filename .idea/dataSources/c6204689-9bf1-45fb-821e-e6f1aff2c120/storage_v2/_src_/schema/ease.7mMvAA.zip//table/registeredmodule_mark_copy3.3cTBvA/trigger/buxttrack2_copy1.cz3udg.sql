create definer = root@`10.10.1.23` trigger BuxtTrack2_copy1
    after UPDATE
    on registeredmodule_mark_copy3
    for each row
    INSERT INTO works.auditmarks VALUES(NULL,NOW(),'UPDATE',NEW.id,NEW.mark,NEW.gradingrule);

