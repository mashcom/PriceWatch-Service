create definer = root@`10.10.1.23` trigger BuxtTrack_copy1
    after INSERT
    on registeredmodule_mark_copy3
    for each row
    INSERT INTO works.auditmarks VALUES(NULL,NOW(),'INSERT',NEW.id,NEW.mark,NEW.gradingrule);

