create view rushwaya as
select `ease`.`programmesession`.`id` AS `id`
from (((`ease`.`student` join `ease`.`programmesession`) join `ease`.`student_personal`)
         join `ease`.`student_nationalid`)
where ((`ease`.`student`.`id` = `ease`.`programmesession`.`studentid`) and
       (`ease`.`student_personal`.`id` = `ease`.`student`.`id`) and
       (`ease`.`student`.`id` = `ease`.`student_nationalid`.`id`) and (not (`ease`.`programmesession`.`id` in
                                                                            (select `ease`.`programmesession_completed`.`id`
                                                                             from `ease`.`programmesession_completed`))) and
       (not (`ease`.`programmesession`.`id` in
             (select `ease`.`programmesession_abborted`.`id` from `ease`.`programmesession_abborted`))) and
       (`ease`.`student`.`regnum` like 'R%') and
       `ease`.`programmesession`.`id` in (select `ease`.`registration`.`programmesessionid`
                                          from `ease`.`registration`
                                          where (`ease`.`registration`.`periodid` > 111)));

