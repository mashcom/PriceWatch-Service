create definer = root@localhost trigger logs2
    after INSERT
    on registration_weblog
    for each row
    INSERT INTO  registration_log VALUES(NEW.id,'ONLINE',NOW());

