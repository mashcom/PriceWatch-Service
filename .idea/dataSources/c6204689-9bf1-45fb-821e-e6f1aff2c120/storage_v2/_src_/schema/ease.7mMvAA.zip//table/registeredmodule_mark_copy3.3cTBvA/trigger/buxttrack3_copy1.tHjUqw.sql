create definer = root@`10.10.1.23` trigger BuxtTrack3_copy1
    after DELETE
    on registeredmodule_mark_copy3
    for each row
    INSERT INTO works.auditmarks VALUES(NULL,NOW(),'DELETE',OLD.id,OLD.mark,OLD.gradingrule);

