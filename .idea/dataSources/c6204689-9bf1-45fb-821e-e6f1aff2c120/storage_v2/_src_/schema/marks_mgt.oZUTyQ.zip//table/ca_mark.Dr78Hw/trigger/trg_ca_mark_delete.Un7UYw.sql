create definer = root@localhost trigger trg_ca_mark_delete
    after DELETE
    on ca_mark
    for each row
BEGIN
	INSERT INTO ca_mark_history (ca_studentid,mark,ecnumber,dateadd,dateupdated) VALUES (OLD.ca_studentid,OLD.mark,OLD.ecnumber,OLD.dateadd,OLD.dateupdated);
    END;

