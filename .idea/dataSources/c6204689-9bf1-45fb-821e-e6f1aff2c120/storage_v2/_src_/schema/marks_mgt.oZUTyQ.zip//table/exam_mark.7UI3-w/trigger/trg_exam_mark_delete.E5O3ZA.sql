create definer = root@localhost trigger trg_exam_mark_delete
    after DELETE
    on exam_mark
    for each row
BEGIN
	INSERT INTO exam_mark_history (class_studentid,mark,ecnumber,dateadd,dateupdated) VALUES (OLD.class_studentid,OLD.mark,OLD.ecnumber,OLD.dateadd,OLD.dateupdated);
    END;

