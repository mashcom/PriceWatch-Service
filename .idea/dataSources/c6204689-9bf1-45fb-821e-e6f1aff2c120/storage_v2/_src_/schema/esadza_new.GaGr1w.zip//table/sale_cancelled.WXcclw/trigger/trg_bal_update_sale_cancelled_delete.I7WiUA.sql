create definer = root@localhost trigger trg_bal_update_sale_cancelled_delete
    after DELETE
    on sale_cancelled
    for each row
BEGIN
	DECLARE amt decimal(10,2);
	declare consid BIGINT;
	SELECT consumerid, (amount * -1) amount INTO consid, amt  FROM sale WHERE saleid = OLD.saleid;
	CALL proc_update_balance(consid, amt);
    END;

