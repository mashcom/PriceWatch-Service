create definer = root@localhost trigger trg_bal_update_sale_allowance_insert
    after INSERT
    on sale_allowance
    for each row
BEGIN
	DECLARE amt decimal(10,2);
	declare consid BIGINT;
	SELECT consumerid,  amount INTO consid, amt  FROM sale WHERE saleid = NEW.saleid;
	CALL proc_update_balance(consid, amt);
    END;

