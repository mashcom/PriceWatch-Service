create
    definer = root@localhost procedure proc_update_balance(IN CONSID int, IN AMT float)
BEGIN
		UPDATE ignore consumer SET balance = balance + AMT WHERE consumerid  =  CONSID;
	END;

