create
    definer = root@localhost procedure proc_update_all_balances()
BEGIN
		DROP temporary TABLE IF EXISTS tbl_update;
		CREATE temporary TABLE tbl_update AS
		SELECT consumerid, SUM(amount) balance
FROM
(
SELECT consumerid, SUM(amount* -1) amount FROM sale WHERE saleid NOT IN (SELECT saleid FROM sale_cancelled) GROUP BY consumerid 
UNION ALL
SELECT consumerid, SUM(amount) amount FROM deposit WHERE depositid NOT IN (SELECT depositid FROM deposit_cancelled) GROUP BY consumerid
UNION ALL
SELECT consumerid, SUM(amount) amount FROM balance_offset GROUP BY consumerid
UNION ALL
SELECT sale.`consumerid`, SUM(sale.`amount`) amount FROM sale_allowance INNER JOIN sale ON sale_allowance.saleid = sale.saleid WHERE sale.saleid NOT IN (SELECT saleid FROM sale_cancelled) GROUP BY sale.`consumerid`
) a GROUP BY consumerid;
	UPDATE consumer 
	INNER JOIN tbl_update ON consumer.`consumerid` = tbl_update.consumerid
	SET consumer.`balance` = tbl_update.balance;
	END;

