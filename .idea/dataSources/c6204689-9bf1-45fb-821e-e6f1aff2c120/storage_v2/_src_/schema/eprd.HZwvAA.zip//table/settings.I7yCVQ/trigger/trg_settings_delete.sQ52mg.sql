create definer = root@localhost trigger trg_settings_delete
    after DELETE
    on settings
    for each row
BEGIN
	INSERT ignore INTO settings_history (`name`,`value`,userid,actiontime) VALUES (OLD.`name`,OLD.`value`,OLD.userid,OLD.actiontime);		
    END;

