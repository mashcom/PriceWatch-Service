create view med_168 as
select `sp`.`regnum` AS `regnum`, `sp`.`periodid` AS `periodid`, `sm`.`membershipno` AS `membershipno`
from (`medicalaid`.`studentprovider` `sp`
         join `medicalaid`.`studentprovider_membership` `sm` on ((`sp`.`id` = `sm`.`id`)))
where (`sp`.`periodid` = 168)
order by `sp`.`regnum`, `sp`.`periodid`;

